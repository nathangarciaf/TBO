#include <stdio.h>

void print_leader(int *v, int size);